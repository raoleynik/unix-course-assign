/********************************************************************************
** Form generated from reading UI file 'conv_length.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONV_LENGTH_H
#define UI_CONV_LENGTH_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Conv_Length
{
public:
    QPushButton *length_exit;
    QPushButton *l_convert;
    QLabel *result;
    QPushButton *l_return;
    QLineEdit *lineEdit;
    QListWidget *LV1;
    QListWidget *LV2;

    void setupUi(QWidget *Conv_Length)
    {
        if (Conv_Length->objectName().isEmpty())
            Conv_Length->setObjectName(QString::fromUtf8("Conv_Length"));
        Conv_Length->setEnabled(true);
        Conv_Length->resize(380, 370);
        Conv_Length->setMinimumSize(QSize(380, 370));
        Conv_Length->setMaximumSize(QSize(380, 370));
        length_exit = new QPushButton(Conv_Length);
        length_exit->setObjectName(QString::fromUtf8("length_exit"));
        length_exit->setGeometry(QRect(90, 300, 80, 24));
        length_exit->setMaximumSize(QSize(90, 24));
        QFont font;
        font.setFamily(QString::fromUtf8("Ubuntu Mono"));
        font.setPointSize(12);
        length_exit->setFont(font);
        length_exit->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        l_convert = new QPushButton(Conv_Length);
        l_convert->setObjectName(QString::fromUtf8("l_convert"));
        l_convert->setGeometry(QRect(120, 240, 130, 24));
        l_convert->setMinimumSize(QSize(130, 24));
        l_convert->setMaximumSize(QSize(130, 24));
        l_convert->setFont(font);
        l_convert->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        result = new QLabel(Conv_Length);
        result->setObjectName(QString::fromUtf8("result"));
        result->setGeometry(QRect(210, 140, 121, 21));
        result->setFont(font);
        result->setAutoFillBackground(false);
        result->setStyleSheet(QString::fromUtf8("background-color : white;\n"
" qproperty-alignment: 'AlignVCenter | AlignRight';\n"
"  border: 1px solid gray;"));
        l_return = new QPushButton(Conv_Length);
        l_return->setObjectName(QString::fromUtf8("l_return"));
        l_return->setGeometry(QRect(200, 300, 80, 24));
        l_return->setMaximumSize(QSize(90, 24));
        l_return->setFont(font);
        l_return->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        lineEdit = new QLineEdit(Conv_Length);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(30, 140, 121, 21));
        lineEdit->setFont(font);
        lineEdit->setStyleSheet(QString::fromUtf8(" qproperty-alignment: 'AlignVCenter | AlignRight';\n"
"  border: 1px solid gray;"));
        LV1 = new QListWidget(Conv_Length);
        LV1->setObjectName(QString::fromUtf8("LV1"));
        LV1->setGeometry(QRect(30, 20, 121, 101));
        LV2 = new QListWidget(Conv_Length);
        LV2->setObjectName(QString::fromUtf8("LV2"));
        LV2->setGeometry(QRect(210, 20, 121, 101));

        retranslateUi(Conv_Length);

        QMetaObject::connectSlotsByName(Conv_Length);
    } // setupUi

    void retranslateUi(QWidget *Conv_Length)
    {
        Conv_Length->setWindowTitle(QCoreApplication::translate("Conv_Length", "Form", nullptr));
        length_exit->setText(QCoreApplication::translate("Conv_Length", "\320\222\321\213\321\205\320\276\320\264", nullptr));
        l_convert->setText(QCoreApplication::translate("Conv_Length", "\320\232\320\276\320\275\320\262\320\265\321\200\321\202\320\270\321\200\320\276\320\262\320\260\321\202\321\214", nullptr));
        result->setText(QString());
        l_return->setText(QCoreApplication::translate("Conv_Length", "\320\235\320\260\320\267\320\260\320\264", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Conv_Length: public Ui_Conv_Length {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONV_LENGTH_H
