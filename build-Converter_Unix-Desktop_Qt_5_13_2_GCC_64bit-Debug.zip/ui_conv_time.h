/********************************************************************************
** Form generated from reading UI file 'conv_time.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONV_TIME_H
#define UI_CONV_TIME_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_conv_time
{
public:
    QPushButton *time_exit;
    QPushButton *t2_convert;
    QLabel *result;
    QListWidget *LV2;
    QPushButton *t2_return;
    QListWidget *LV1;
    QLineEdit *lineEdit;

    void setupUi(QWidget *conv_time)
    {
        if (conv_time->objectName().isEmpty())
            conv_time->setObjectName(QString::fromUtf8("conv_time"));
        conv_time->resize(380, 370);
        conv_time->setMinimumSize(QSize(380, 370));
        conv_time->setMaximumSize(QSize(380, 370));
        time_exit = new QPushButton(conv_time);
        time_exit->setObjectName(QString::fromUtf8("time_exit"));
        time_exit->setGeometry(QRect(90, 310, 80, 24));
        time_exit->setMaximumSize(QSize(90, 24));
        QFont font;
        font.setFamily(QString::fromUtf8("Ubuntu Mono"));
        font.setPointSize(12);
        time_exit->setFont(font);
        time_exit->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        t2_convert = new QPushButton(conv_time);
        t2_convert->setObjectName(QString::fromUtf8("t2_convert"));
        t2_convert->setGeometry(QRect(120, 250, 130, 24));
        t2_convert->setMinimumSize(QSize(130, 24));
        t2_convert->setMaximumSize(QSize(130, 24));
        t2_convert->setFont(font);
        t2_convert->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        result = new QLabel(conv_time);
        result->setObjectName(QString::fromUtf8("result"));
        result->setGeometry(QRect(210, 150, 121, 21));
        result->setFont(font);
        result->setAutoFillBackground(false);
        result->setStyleSheet(QString::fromUtf8("background-color : white;\n"
" qproperty-alignment: 'AlignVCenter | AlignRight';\n"
"  border: 1px solid gray;"));
        LV2 = new QListWidget(conv_time);
        LV2->setObjectName(QString::fromUtf8("LV2"));
        LV2->setGeometry(QRect(210, 30, 121, 101));
        t2_return = new QPushButton(conv_time);
        t2_return->setObjectName(QString::fromUtf8("t2_return"));
        t2_return->setGeometry(QRect(200, 310, 80, 24));
        t2_return->setMaximumSize(QSize(90, 24));
        t2_return->setFont(font);
        t2_return->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        LV1 = new QListWidget(conv_time);
        LV1->setObjectName(QString::fromUtf8("LV1"));
        LV1->setGeometry(QRect(30, 30, 121, 101));
        lineEdit = new QLineEdit(conv_time);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(30, 150, 121, 21));
        lineEdit->setFont(font);
        lineEdit->setStyleSheet(QString::fromUtf8(" qproperty-alignment: 'AlignVCenter | AlignRight';\n"
"  border: 1px solid gray;"));

        retranslateUi(conv_time);

        QMetaObject::connectSlotsByName(conv_time);
    } // setupUi

    void retranslateUi(QWidget *conv_time)
    {
        conv_time->setWindowTitle(QCoreApplication::translate("conv_time", "Form", nullptr));
        time_exit->setText(QCoreApplication::translate("conv_time", "\320\222\321\213\321\205\320\276\320\264", nullptr));
        t2_convert->setText(QCoreApplication::translate("conv_time", "\320\232\320\276\320\275\320\262\320\265\321\200\321\202\320\270\321\200\320\276\320\262\320\260\321\202\321\214", nullptr));
        result->setText(QString());
        t2_return->setText(QCoreApplication::translate("conv_time", "\320\235\320\260\320\267\320\260\320\264", nullptr));
    } // retranslateUi

};

namespace Ui {
    class conv_time: public Ui_conv_time {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONV_TIME_H
