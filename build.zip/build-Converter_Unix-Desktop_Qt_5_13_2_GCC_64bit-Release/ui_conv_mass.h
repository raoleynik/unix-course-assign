/********************************************************************************
** Form generated from reading UI file 'conv_mass.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONV_MASS_H
#define UI_CONV_MASS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_conv_mass
{
public:
    QPushButton *mass_exit;
    QPushButton *m_convert;
    QLabel *result;
    QListWidget *LV2;
    QListWidget *LV1;
    QPushButton *m_return;
    QLineEdit *lineEdit;

    void setupUi(QWidget *conv_mass)
    {
        if (conv_mass->objectName().isEmpty())
            conv_mass->setObjectName(QString::fromUtf8("conv_mass"));
        conv_mass->resize(380, 370);
        conv_mass->setMinimumSize(QSize(380, 370));
        conv_mass->setMaximumSize(QSize(380, 370));
        mass_exit = new QPushButton(conv_mass);
        mass_exit->setObjectName(QString::fromUtf8("mass_exit"));
        mass_exit->setGeometry(QRect(100, 320, 80, 24));
        mass_exit->setMaximumSize(QSize(90, 24));
        QFont font;
        font.setFamily(QString::fromUtf8("Ubuntu Mono"));
        font.setPointSize(12);
        mass_exit->setFont(font);
        mass_exit->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        m_convert = new QPushButton(conv_mass);
        m_convert->setObjectName(QString::fromUtf8("m_convert"));
        m_convert->setGeometry(QRect(130, 260, 130, 24));
        m_convert->setMinimumSize(QSize(130, 24));
        m_convert->setMaximumSize(QSize(130, 24));
        m_convert->setFont(font);
        m_convert->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        result = new QLabel(conv_mass);
        result->setObjectName(QString::fromUtf8("result"));
        result->setGeometry(QRect(220, 160, 121, 21));
        result->setFont(font);
        result->setAutoFillBackground(false);
        result->setStyleSheet(QString::fromUtf8("background-color : white;\n"
" qproperty-alignment: 'AlignVCenter | AlignRight';\n"
"  border: 1px solid gray;"));
        LV2 = new QListWidget(conv_mass);
        LV2->setObjectName(QString::fromUtf8("LV2"));
        LV2->setGeometry(QRect(220, 40, 121, 101));
        LV1 = new QListWidget(conv_mass);
        LV1->setObjectName(QString::fromUtf8("LV1"));
        LV1->setGeometry(QRect(40, 40, 121, 101));
        m_return = new QPushButton(conv_mass);
        m_return->setObjectName(QString::fromUtf8("m_return"));
        m_return->setGeometry(QRect(210, 320, 80, 24));
        m_return->setMaximumSize(QSize(90, 24));
        m_return->setFont(font);
        m_return->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        lineEdit = new QLineEdit(conv_mass);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(40, 160, 121, 21));
        lineEdit->setFont(font);
        lineEdit->setStyleSheet(QString::fromUtf8(" qproperty-alignment: 'AlignVCenter | AlignRight';\n"
"  border: 1px solid gray;"));

        retranslateUi(conv_mass);

        QMetaObject::connectSlotsByName(conv_mass);
    } // setupUi

    void retranslateUi(QWidget *conv_mass)
    {
        conv_mass->setWindowTitle(QCoreApplication::translate("conv_mass", "Form", nullptr));
        mass_exit->setText(QCoreApplication::translate("conv_mass", "\320\222\321\213\321\205\320\276\320\264", nullptr));
        m_convert->setText(QCoreApplication::translate("conv_mass", "\320\232\320\276\320\275\320\262\320\265\321\200\321\202\320\270\321\200\320\276\320\262\320\260\321\202\321\214", nullptr));
        result->setText(QString());
        m_return->setText(QCoreApplication::translate("conv_mass", "\320\235\320\260\320\267\320\260\320\264", nullptr));
    } // retranslateUi

};

namespace Ui {
    class conv_mass: public Ui_conv_mass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONV_MASS_H
