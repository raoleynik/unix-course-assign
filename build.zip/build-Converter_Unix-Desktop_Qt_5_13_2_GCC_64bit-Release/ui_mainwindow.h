/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *PushButton_exit;
    QPushButton *PushButton_Conv_Length_Open;
    QPushButton *PushButton_Conv_Temp_Open;
    QPushButton *PushButton_Conv_Mass_Open;
    QPushButton *PushButton_Conv_Time_Open;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(380, 370);
        MainWindow->setMinimumSize(QSize(380, 370));
        MainWindow->setMaximumSize(QSize(380, 370));
        QFont font;
        font.setFamily(QString::fromUtf8("Ubuntu Mono"));
        font.setPointSize(12);
        MainWindow->setFont(font);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        PushButton_exit = new QPushButton(centralwidget);
        PushButton_exit->setObjectName(QString::fromUtf8("PushButton_exit"));
        PushButton_exit->setGeometry(QRect(145, 300, 90, 24));
        PushButton_exit->setMaximumSize(QSize(90, 24));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Ubuntu Mono"));
        font1.setPointSize(12);
        font1.setBold(false);
        font1.setItalic(false);
        font1.setWeight(50);
        PushButton_exit->setFont(font1);
        PushButton_exit->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        PushButton_Conv_Length_Open = new QPushButton(centralwidget);
        PushButton_Conv_Length_Open->setObjectName(QString::fromUtf8("PushButton_Conv_Length_Open"));
        PushButton_Conv_Length_Open->setGeometry(QRect(55, 40, 270, 24));
        PushButton_Conv_Length_Open->setMaximumSize(QSize(270, 24));
        PushButton_Conv_Length_Open->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        PushButton_Conv_Temp_Open = new QPushButton(centralwidget);
        PushButton_Conv_Temp_Open->setObjectName(QString::fromUtf8("PushButton_Conv_Temp_Open"));
        PushButton_Conv_Temp_Open->setGeometry(QRect(55, 80, 270, 24));
        PushButton_Conv_Temp_Open->setMaximumSize(QSize(270, 24));
        PushButton_Conv_Temp_Open->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        PushButton_Conv_Mass_Open = new QPushButton(centralwidget);
        PushButton_Conv_Mass_Open->setObjectName(QString::fromUtf8("PushButton_Conv_Mass_Open"));
        PushButton_Conv_Mass_Open->setGeometry(QRect(55, 120, 270, 24));
        PushButton_Conv_Mass_Open->setMaximumSize(QSize(270, 24));
        PushButton_Conv_Mass_Open->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        PushButton_Conv_Time_Open = new QPushButton(centralwidget);
        PushButton_Conv_Time_Open->setObjectName(QString::fromUtf8("PushButton_Conv_Time_Open"));
        PushButton_Conv_Time_Open->setGeometry(QRect(55, 160, 270, 24));
        PushButton_Conv_Time_Open->setMaximumSize(QSize(270, 24));
        PushButton_Conv_Time_Open->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 380, 22));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        PushButton_exit->setText(QCoreApplication::translate("MainWindow", "\320\222\321\213\321\205\320\276\320\264", nullptr));
        PushButton_Conv_Length_Open->setText(QCoreApplication::translate("MainWindow", "\320\232\320\276\320\275\320\262\320\265\321\200\321\202\320\265\321\200 \320\264\320\273\320\270\320\275\321\213", nullptr));
        PushButton_Conv_Temp_Open->setText(QCoreApplication::translate("MainWindow", "\320\232\320\276\320\275\320\262\320\265\321\200\321\202\320\265\321\200 \321\202\320\265\320\274\320\277\320\265\321\200\320\260\321\202\321\203\321\200\321\213", nullptr));
        PushButton_Conv_Mass_Open->setText(QCoreApplication::translate("MainWindow", "\320\232\320\276\320\275\320\262\320\265\321\200\321\202\320\265\321\200 \320\274\320\260\321\201\321\201\321\213", nullptr));
        PushButton_Conv_Time_Open->setText(QCoreApplication::translate("MainWindow", "\320\232\320\276\320\275\320\262\320\265\321\200\321\202\320\265\321\200 \320\262\321\200\320\265\320\274\320\265\320\275\320\270", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
