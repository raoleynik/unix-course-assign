/********************************************************************************
** Form generated from reading UI file 'conv_temp.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONV_TEMP_H
#define UI_CONV_TEMP_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_conv_temp
{
public:
    QPushButton *t_return;
    QPushButton *temp_exit;
    QPushButton *t_convert;
    QListWidget *LV2;
    QLineEdit *lineEdit;
    QLabel *result;
    QListWidget *LV1;

    void setupUi(QWidget *conv_temp)
    {
        if (conv_temp->objectName().isEmpty())
            conv_temp->setObjectName(QString::fromUtf8("conv_temp"));
        conv_temp->resize(380, 370);
        conv_temp->setMinimumSize(QSize(380, 370));
        conv_temp->setMaximumSize(QSize(380, 370));
        t_return = new QPushButton(conv_temp);
        t_return->setObjectName(QString::fromUtf8("t_return"));
        t_return->setGeometry(QRect(210, 310, 80, 24));
        t_return->setMaximumSize(QSize(90, 24));
        QFont font;
        font.setFamily(QString::fromUtf8("Ubuntu Mono"));
        font.setPointSize(12);
        t_return->setFont(font);
        t_return->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        temp_exit = new QPushButton(conv_temp);
        temp_exit->setObjectName(QString::fromUtf8("temp_exit"));
        temp_exit->setGeometry(QRect(100, 310, 80, 24));
        temp_exit->setMaximumSize(QSize(90, 24));
        temp_exit->setFont(font);
        temp_exit->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        t_convert = new QPushButton(conv_temp);
        t_convert->setObjectName(QString::fromUtf8("t_convert"));
        t_convert->setGeometry(QRect(130, 250, 130, 24));
        t_convert->setMinimumSize(QSize(130, 24));
        t_convert->setMaximumSize(QSize(130, 24));
        t_convert->setFont(font);
        t_convert->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        LV2 = new QListWidget(conv_temp);
        LV2->setObjectName(QString::fromUtf8("LV2"));
        LV2->setGeometry(QRect(220, 30, 121, 101));
        lineEdit = new QLineEdit(conv_temp);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(40, 150, 121, 21));
        lineEdit->setFont(font);
        lineEdit->setStyleSheet(QString::fromUtf8(" qproperty-alignment: 'AlignVCenter | AlignRight';\n"
"  border: 1px solid gray;"));
        result = new QLabel(conv_temp);
        result->setObjectName(QString::fromUtf8("result"));
        result->setGeometry(QRect(220, 150, 121, 21));
        result->setFont(font);
        result->setAutoFillBackground(false);
        result->setStyleSheet(QString::fromUtf8("background-color : white;\n"
" qproperty-alignment: 'AlignVCenter | AlignRight';\n"
"  border: 1px solid gray;"));
        LV1 = new QListWidget(conv_temp);
        LV1->setObjectName(QString::fromUtf8("LV1"));
        LV1->setGeometry(QRect(40, 30, 121, 101));

        retranslateUi(conv_temp);

        QMetaObject::connectSlotsByName(conv_temp);
    } // setupUi

    void retranslateUi(QWidget *conv_temp)
    {
        conv_temp->setWindowTitle(QCoreApplication::translate("conv_temp", "Form", nullptr));
        t_return->setText(QCoreApplication::translate("conv_temp", "\320\235\320\260\320\267\320\260\320\264", nullptr));
        temp_exit->setText(QCoreApplication::translate("conv_temp", "\320\222\321\213\321\205\320\276\320\264", nullptr));
        t_convert->setText(QCoreApplication::translate("conv_temp", "\320\232\320\276\320\275\320\262\320\265\321\200\321\202\320\270\321\200\320\276\320\262\320\260\321\202\321\214", nullptr));
        result->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class conv_temp: public Ui_conv_temp {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONV_TEMP_H
